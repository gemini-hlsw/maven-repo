/*
 * Copyright 2022 Typelevel
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.typelevel.sbt

import com.jsuereth.sbtpgp.SbtPgp
import com.jsuereth.sbtpgp.SbtPgp.autoImport.useGpgAgent
import org.typelevel.sbt.gha.GenerativePlugin
import org.typelevel.sbt.gha.GenerativePlugin.autoImport._
import org.typelevel.sbt.gha.GitHubActionsPlugin
import sbt._
import com.jsuereth.sbtpgp.PgpKeys
import com.jsuereth.sbtpgp.PgpKeys._
import sbt.Keys._
import sbtcompat.PluginCompat._

object TypelevelCiSigningPlugin extends AutoPlugin {
  // TODO: Zainab - Workaround for https://github.com/sbt/sbt-pgp/issues/246
  private def deliverPattern(outputPath: File): String =
    (outputPath / "[artifact]-[revision](-[classifier]).[ext]").absolutePath

  override def requires = SbtPgp && GitHubActionsPlugin && GenerativePlugin

  override def trigger = allRequirements

  override def buildSettings = Seq(
    githubWorkflowPublishPreamble := Seq(
      // The command below is supported but interpreted differently on Linux and macOS runners.
      //   Linux: base64 --decode --ignore-garbage -
      //   macOS: base64 --decode --input -
      // On Linux, the `-` is a positional argument, on macOS it is the parameter to `--input`.
      WorkflowStep.Run( // if your key is not passphrase-protected
        List("echo $PGP_SECRET | base64 -d -i - | gpg --import"),
        name = Some("Import signing key"),
        cond = Some("env.PGP_SECRET != '' && env.PGP_PASSPHRASE == ''"),
        env = env
      ),
      WorkflowStep.Run( // if your key is passphrase-protected
        List(
          "echo \"$PGP_SECRET\" | base64 -d -i - > /tmp/signing-key.gpg",
          "echo \"$PGP_PASSPHRASE\" | gpg --pinentry-mode loopback --passphrase-fd 0 --import /tmp/signing-key.gpg",
          "(echo \"$PGP_PASSPHRASE\"; echo; echo) | gpg --command-fd 0 --pinentry-mode loopback --change-passphrase $(gpg --list-secret-keys --with-colons 2> /dev/null | grep '^sec:' | cut --delimiter ':' --fields 5 | tail -n 1)"
        ),
        name = Some("Import signing key and strip passphrase"),
        cond = Some("env.PGP_SECRET != '' && env.PGP_PASSPHRASE != ''"),
        env = env
      )
    )
  )

  override def projectSettings = Seq(
    useGpgAgent := false,
    // TODO: Zainab - Workaround for https://github.com/sbt/sbt-pgp/issues/246
    publishLocalSignedConfiguration := {
      println("Using our one.")
      implicit val conv: xsbti.FileConverter = fileConverter.value
      Classpaths.publishConfig(
        publishMavenStyle.value,
        deliverPattern(crossTarget.value),
        if (isSnapshot.value) "integration" else "release",
        ivyConfigurations.value.map(c => ConfigRef(c.name)).toVector,
        PgpKeys.signedArtifacts.value.toVector.map { case (a, x) =>
          a -> toFile(x)
        },
        (publishLocal / checksums).value.toVector,
        resolverName = "local",
        logging = ivyLoggingLevel.value,
        overwrite = publishConfiguration.value.overwrite
      )
    },

  )

  private val env = Map(
    "PGP_SECRET" -> s"$${{ secrets.PGP_SECRET }}",
    "PGP_PASSPHRASE" -> s"$${{ secrets.PGP_PASSPHRASE }}"
  )

}
