/*
 * Copyright 2022 Typelevel
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.typelevel.sbt

import com.github.sbt.git.SbtGit.git
import org.scalajs.sbtplugin.ScalaJSPlugin
import org.typelevel.sbt.kernel.GitHelper
import sbt._

import Keys._

object TypelevelScalaJSGitHubPlugin extends AutoPlugin {
  override def trigger = allRequirements
  override def requires = ScalaJSPlugin && TypelevelKernelPlugin

  import TypelevelKernelPlugin.autoImport._
  import ScalaJSPlugin.autoImport._

  private val sourceMapOptions = Def.task {
    val flag = if (tlIsScala3.value) "-scalajs-mapSourceURI:" else "-P:scalajs:mapSourceURI:"

    val tagOrHash =
      GitHelper
        .getTagOrHash(git.gitCurrentTags.value, git.gitHeadCommit.value)
        // Don't include the flag if there are uncommitted changes, since the tag or hash would be inaccurate
        .filterNot(_ => git.gitUncommittedChanges.value)

    val l = (LocalRootProject / baseDirectory).value.toURI.toString

    tagOrHash.flatMap { v =>
      scmInfo.value.map { info =>
        val g =
          s"${info.browseUrl.toString.replace("github.com", "raw.githubusercontent.com")}/$v/"
        s"$flag$l->$g"
      }
    }
  }
  override def projectSettings = Seq(
    scalacOptions ++= sourceMapOptions.value,
    scalaJSLinkerConfig := {
      scalaJSLinkerConfig.value.withBatchMode(sys.env.get("GITHUB_ACTIONS").contains("true"))
    }
  )
}
