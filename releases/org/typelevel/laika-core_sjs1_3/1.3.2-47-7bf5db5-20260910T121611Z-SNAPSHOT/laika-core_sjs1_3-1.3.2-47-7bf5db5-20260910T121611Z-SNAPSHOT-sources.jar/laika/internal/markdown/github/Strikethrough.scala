/*
 * Copyright 2012-2020 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package laika.internal.markdown.github

import laika.api.bundle.SpanParserBuilder
import laika.ast.Deleted
import laika.internal.markdown.InlineParsers.enclosedByDoubleChar

/** Parser for spans with strike-through markup.
  *
  * For the spec see [[https://github.github.com/gfm/#strikethrough-extension-]].
  *
  * @author Jens Halm
  */
private[laika] object Strikethrough {

  val parser: SpanParserBuilder = SpanParserBuilder.recursive { implicit recParsers =>
    enclosedByDoubleChar('~').map { Deleted(_) }
  }

}
