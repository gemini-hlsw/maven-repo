/*
 * Copyright 2012-2020 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package laika.internal.rst.bundle

import laika.api.bundle.{ BundleOrigin, ExtensionBundle, ParserBundle }
import laika.ast.RewriteRules.RewritePhaseBuilder
import laika.ast.{ Block, RewritePhase, Span }
import laika.internal.rst.InlineParsers
import laika.internal.rst.ext.Directives.Directive
import laika.internal.rst.ext.ExtensionParsers
import laika.internal.rst.ext.TextRoles.TextRole
import laika.parse.markup.RecursiveParsers

/** Internal API that processes all extensions defined
  * by one or more RstExtensionRegistries. This extension
  * is installed by default when using the reStructuredText
  * parser.
  *
  * @author Jens Halm
  */
private[rst] class RstExtensionSupport(
    blockDirectives: Seq[Directive[Block]],
    spanDirectives: Seq[Directive[Span]],
    textRoles: Seq[TextRole],
    defaultTextRole: String
) extends ExtensionBundle {

  val description: String = "Support for user-defined reStructuredText directives"

  override val origin: BundleOrigin = BundleOrigin.Parser

  override def rewriteRules: RewritePhaseBuilder = { case RewritePhase.Resolve =>
    Seq(new RewriteRules(textRoles))
  }

  override lazy val parsers: ParserBundle = new ParserBundle(
    blockParsers = Seq(
      ExtensionParsers.allBlocks(blockDirectives, spanDirectives, textRoles, defaultTextRole)
    ),
    spanParsers = Seq(
      InlineParsers.interpretedTextWithRoleSuffix(defaultTextRole)
    )
  )

  def withDirectives(
      newBlockDirectives: Seq[Directive[Block]],
      newSpanDirectives: Seq[Directive[Span]],
      newTextRoles: Seq[TextRole],
      newDefaultTextRole: Option[String] = None
  ): RstExtensionSupport =
    new RstExtensionSupport(
      blockDirectives ++ newBlockDirectives,
      spanDirectives ++ newSpanDirectives,
      textRoles ++ newTextRoles,
      newDefaultTextRole.getOrElse(defaultTextRole)
    )

}

/** Empty base instance as a basis for registering reStructuredText extensions.
  */
private[laika] object RstExtensionSupport
    extends RstExtensionSupport(Nil, Nil, Nil, "title-reference")

/** Common base trait for reStructuredText extensions (directives and text roles).
  */
private[rst] trait RstExtension[P] {

  /** The name the extension is identified by in text markup.
    */
  def name: String

  /** The factory creating an instance of the extension based
    * on the recursive parsers of the host language.
    */
  def part: RecursiveParsers => P

}

/** Companion with utilities for initializing extensions.
  */
private[rst] object RstExtension {

  /** Initializes the specified extensions with the given recursive parsers
    * and returns them as a map keyed by the name of the extension.
    */
  def createAsMap[P](ext: Seq[RstExtension[P]], recParsers: RecursiveParsers): Map[String, P] =
    ext.map { e => (e.name.toLowerCase, e.part(recParsers)) }.toMap

}
