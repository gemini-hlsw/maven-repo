// Copyright (c) 2016-2026 Association of Universities for Research in Astronomy, Inc. (AURA)
// For license information see LICENSE or https://opensource.org/licenses/BSD-3-Clause

package lucuma.sbtplugin

import com.github.sbt.git.SbtGit.GitKeys.useConsoleForROGit
import com.github.sbt.git.SbtGit.git
import org.scalafmt.sbt.ScalafmtPlugin
import org.typelevel.sbt.*
import org.typelevel.sbt.gha.GenerativePlugin
import org.typelevel.sbt.gha.GitHubActionsPlugin
import org.typelevel.sbt.mergify.MergifyPlugin
import sbt.Keys.*
import sbt.{*, given}
import sbtheader.AutomateHeaderPlugin
import sbtheader.HeaderPlugin
import scalafix.sbt.ScalafixPlugin

object LucumaPlugin extends AutoPlugin {

  import GenerativePlugin.autoImport._
  import GitHubActionsPlugin.autoImport._
  import HeaderPlugin.autoImport._
  import MergifyPlugin.autoImport._
  import ScalafixPlugin.autoImport._
  import TypelevelCiPlugin.autoImport._
  import TypelevelSettingsPlugin.autoImport._
  import TypelevelKernelPlugin.autoImport._

  object autoImport {

    lazy val lucumaGlobalSettings = Seq(
      semanticdbEnabled := true,                       // enable SemanticDB
      semanticdbVersion := scalafixSemanticdb.revision // use Scalafix compatible version
    )

    lazy val lucumaScalaVersionSettings = Seq(
      crossScalaVersions := Seq("3.9.0"),
      scalaVersion       := crossScalaVersions.value.head
    )

    lazy val lucumaScalacSettings = Seq(
      tlJdkRelease := Some(25)
    )

    lazy val lucumaScalacProjectSettings = Seq(
      // workaround https://github.com/fthomas/refined/pull/1317
      scalacOptions += "-Wconf:msg=Given search preference for .*WitnessAs:s",
      // Move this the sbt-typelevel plugin?
      // sbt-typelevel has better facilities for checking verions, but they are private
      scalacOptions ++= {
        if (scalaVersion.value.startsWith("3"))
          Seq("-Wunused:nowarn")
        else
          Seq.empty
      }
    )

    lazy val lucumaDocSettings = Seq(
      Compile / doc / sources := Seq.empty
    )

    // Under sbt 2 `src_managed` sits inside the project's output directory, so a generated
    // source reaches the mappings by both routes and the zip rejects the duplicate entry.
    lazy val lucumaPackageSettings = Seq(
      Compile / packageSrc / mappings ~= (_.distinct)
    )

    lazy val lucumaHeaderSettings = Seq(
      headerMappings := headerMappings.value + (HeaderFileType.scala -> HeaderCommentStyle.cppStyleLineComment),
      headerLicense  := Some(
        HeaderLicense.Custom(
          """|Copyright (c) 2016-2026 Association of Universities for Research in Astronomy, Inc. (AURA)
           |For license information see LICENSE or https://opensource.org/licenses/BSD-3-Clause
           |""".stripMargin
        )
      )
    )

    lazy val lucumaPublishSettings = Seq(
      organization     := "edu.gemini",
      organizationName := "Association of Universities for Research in Astronomy, Inc. (AURA)",
      licenses += (("BSD-3-Clause", uri("https://opensource.org/licenses/BSD-3-Clause"))),
      developers       := List(
        Developer("cquiroz", "Carlos Quiroz", "cquiroz@gemini.edu", uri("https://www.gemini.edu")),
        Developer("jluhrs", "Javier Lührs", "jluhrs@gemini.edu", uri("https://www.gemini.edu")),
        Developer("sraaphorst",
                  "Sebastian Raaphorst",
                  "sraaphorst@gemini.edu",
                  uri("https://www.gemini.edu")
        ),
        Developer("swalker2m", "Shane Walker", "swalker@gemini.edu", uri("https://www.gemini.edu")),
        Developer("tpolecat", "Rob Norris", "rnorris@gemini.edu", uri("https://www.tpolecat.org")),
        Developer("rpiaggio", "Raúl Piaggio", "rpiaggio@gemini.edu", uri("https://www.gemini.edu")),
        Developer("toddburnside",
                  "Todd Burnside",
                  "tburnside@gemini.edu",
                  uri("https://www.gemini.edu")
        ),
        Developer("hugo-vrijswijk",
                  "Hugo van Rijswijjk",
                  "hugovr@castor-it.nl",
                  uri("https://www.gemini.edu")
        )
      )
    )

    lazy val lucumaCiSettings = Seq(
      githubWorkflowJavaVersions   := Seq(JavaSpec.temurin("25")),
      Def.derive(tlFatalWarnings := githubIsWorkflowBuild.value),
      evictionErrorLevel           := {
        if (githubIsWorkflowBuild.value)
          Level.Error // fatal in CI
        else
          Level.Warn  // relaxed locally for snapshot testing, etc.
      },
      mergifyStewardConfig         := Some(
        MergifyStewardConfig(author = "lucuma-steward[bot]", mergeMinors = true)
      ),
      mergifyPrRules ~= {
        _.map { rule =>
          rule.copy(conditions = rule.conditions.map {
            case MergifyCondition.Or(conditions) =>
              MergifyCondition.Or(
                conditions ::: MergifyCondition.Custom("title=flake.lock: Update") :: Nil
              )
            case other                           => other
          })
        }
      },
      tlCiHeaderCheck              := true,
      tlCiScalafmtCheck            := true,
      githubWorkflowBuild          :=
        githubWorkflowBuild.value.map {
          case step: WorkflowStep.Sbt if step.name.exists(_.contains("Check headers")) =>
            WorkflowStep.Sbt(
              commands = step.commands ++
                List("lucumaScalafmtCheck").filter(_ => tlCiScalafmtCheck.value) ++
                List("lucumaScalafixCheck").filter(_ => tlCiScalafixCheck.value),
              step.id,
              step.name,
              step.cond,
              step.env,
              step.params,
              step.timeoutMinutes,
              step.preamble,
              step.continueOnError
            )
          case step                                                                    => step
        },
      tlCiScalafixCheck            := true,
      tlCiDocCheck                 := false, // we are generating empty docs anyway
      tlCiDependencyGraphJob       := false,
      githubWorkflowArtifactUpload := true
    )

    lazy val lucumaGitSettings = Seq(
      useConsoleForROGit        := (baseDirectory.value / ".git").isFile,
      git.gitUncommittedChanges := {
        if (githubIsWorkflowBuild.value) {
          git.gitUncommittedChanges.value
        } else {
          import scala.sys.process._
          import scala.util.Try

          Try("git status -s".!!.trim.length > 0).getOrElse(true)
        }
      }
    )

    lazy val lucumaDockerComposeSettings = Seq(
      githubWorkflowBuildPreamble ++= {
        if (hasDockerComposeYml.value)
          Seq(WorkflowStep.Run(List("docker compose up -d"), name = Some("Docker compose up")))
        else Nil
      },
      githubWorkflowBuildPostamble ++= {
        if (hasDockerComposeYml.value)
          Seq(WorkflowStep.Run(List("docker compose down"), name = Some("Docker compose down")))
        else Nil
      }
    )

    lazy val lucumaStewardSettings = Seq(
      GlobalScope / tlCommandAliases += {
        val command =
          List("githubWorkflowGenerate", "+headerCreateAll") ++
            List("lucumaScalafmtGenerate", "+scalafmtAll", "scalafmtSbt")
              .filter(_ => tlCiScalafmtCheck.value) ++
            List("lucumaScalafixGenerate").filter(_ => tlCiScalafixCheck.value)

        "tlPrePrBotHook" -> command
      }
    )

  }

  private val hasDockerComposeYml = Def.setting {
    file("docker-compose.yml").exists()
  }

  import autoImport._

  override def requires =
    TypelevelCiPlugin &&
      TypelevelGitHubPlugin &&
      TypelevelSettingsPlugin &&
      HeaderPlugin &&
      ScalafmtPlugin &&
      LucumaScalafmtPlugin &&
      LucumaScalafixPlugin &&
      GenerativePlugin &&
      GitHubActionsPlugin

  override def trigger: PluginTrigger =
    allRequirements

  override val globalSettings =
    lucumaGlobalSettings

  override val buildSettings =
    lucumaScalaVersionSettings ++
      lucumaScalacSettings ++
      lucumaPublishSettings ++
      lucumaCiSettings ++
      lucumaDockerComposeSettings ++
      lucumaStewardSettings ++
      lucumaGitSettings ++
      commandAliasSettings

  override val projectSettings =
    lucumaDocSettings ++ lucumaPackageSettings ++ lucumaHeaderSettings ++ lucumaScalacProjectSettings ++ AutomateHeaderPlugin.projectSettings

  lazy val commandAliasSettings: Seq[Setting[?]] = commandAliasSettings(Nil)

  def commandAliasSettings(extra: List[String]): Seq[Setting[?]] = Seq(
    GlobalScope / tlCommandAliases += {
      val command =
        List(
          "reload",
          "project /",
          "clean",
          "githubWorkflowGenerate",
          "headerCreateAll"
        ) ++
          List("lucumaScalafixGenerate", "scalafixAll").filter(_ => tlCiScalafixCheck.value) ++
          List("lucumaScalafmtGenerate", "scalafmtAll", "scalafmtSbt")
            .filter(_ => tlCiScalafmtCheck.value) ++
          extra

      "prePR" -> command
    }
  )

}
